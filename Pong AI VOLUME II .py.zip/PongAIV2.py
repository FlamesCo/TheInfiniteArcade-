 
import pygame

# Initialize Pygame
pygame.init()

# Set the window size
screen_width = 600
screen_height = 400

# Create the screen
screen = pygame.display.set_mode((screen_width, screen_height))

# Set the background color
bg_color = (0, 0, 0)

# Create the paddles
paddle_width = 20
paddle_height = 100

left_paddle = pygame.Rect(10, screen_height // 2 - paddle_height // 2, paddle_width, paddle_height)
right_paddle = pygame.Rect(screen_width - paddle_width - 10, screen_height // 2 - paddle_height // 2, paddle_width, paddle_height)

# Create the ball
ball_radius = 10
ball_x = screen_width // 2
ball_y = screen_height // 2
ball_dx = 5
ball_dy = 5

# Create the score variables
left_score = 0
right_score = 0

# Create the game loop
while True:

    # Clear the screen
    screen.fill(bg_color)

    # Check for events
    for event in pygame.event.get():
        if event.type == pygame.QUIT:
            break

        # Move the left paddle
        if event.type == pygame.KEYDOWN and event.key == pygame.K_UP:
            left_paddle.y -= 5

        if event.type == pygame.KEYDOWN and event.key == pygame.K_DOWN:
            left_paddle.y += 5

        # Move the right paddle
        if event.type == pygame.KEYDOWN and event.key == pygame.K_w:
            right_paddle.y -= 5

        if event.type == pygame.KEYDOWN and event.key == pygame.K_s:
            right_paddle.y += 5

    # Move the ball
    ball_x += ball_dx
    ball_y += ball_dy

    # Check if the ball hit the top or bottom of the screen
    if ball_y <= 0 or ball_y >= screen_height - ball_radius:
        ball_dy *= -1

    # Check if the ball hit the left or right paddle
    if ball_x <= left_paddle.x + paddle_width:
        if ball_y >= left_paddle.y and ball_y <= left_paddle.y + paddle_height:
            ball_dx *= -1

    if ball_x >= right_paddle.x - paddle_width:
        if ball_y >= right_paddle.y and ball_y <= right_paddle.y + paddle_height:
            ball_dx *= -1

    # Check if the ball went out of bounds
    if ball_x < 0:
        right_score += 1
        ball_x = screen_width // 2
        ball_y = screen_height // 2

    if ball_x > screen_width:
        left_score += 1
        ball_x = screen_width // 2
        ball_y = screen_height // 2

    # Draw the paddles
    pygame.draw.rect(screen, (255, 255, 255), left_paddle)
    pygame.draw.rect(screen, (255, 255, 255), right_paddle)

    # Draw the ball
    pygame.draw.circle(screen, (255, 255, 255), (ball_x, ball_y), ball_radius)

    # Update the display
    pygame.display.update()

# Quit Pygame
pygame.quit()
 